package com.solent.mainapp;

import com.solent.mainapp.dao.FAQDAO;
import java.sql.Connection;
import java.util.List;

public class FAQService {
    private FAQDAO faqDAO;

    public FAQService(Connection conn) {
        this.faqDAO = new FAQDAO(conn);
    }

    public List<FAQ> getAllFAQs() {
        return faqDAO.getAllFAQs();
    }

    public void addFAQ(FAQ faq) {
        faqDAO.addFAQ(faq);
    }

    public void deleteFAQ(int id) {
        faqDAO.deleteFAQ(id);
    }
}
