package com.solent.mainapp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


public class DataManager {
    private static Connection conn;

    public static Connection getConnection() {
        if (conn == null) {
            try {
                Class.forName("org.sqlite.JDBC");
                conn = DriverManager.getConnection("jdbc:sqlite:database/campusassist.db");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return conn;
    }
}