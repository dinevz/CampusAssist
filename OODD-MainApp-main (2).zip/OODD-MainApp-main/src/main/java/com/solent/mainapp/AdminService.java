package com.solent.mainapp;

import com.solent.mainapp.dao.AppointmentDAO;
import com.solent.mainapp.dao.FAQDAO;
import java.sql.Connection;
import java.util.List;

public class AdminService {
    private AppointmentDAO appointmentDAO;
    private FAQDAO faqDAO;

    public AdminService(Connection conn) {
        this.appointmentDAO = new AppointmentDAO(conn);
        this.faqDAO = new FAQDAO(conn);
    }

    public List<Appointment> getAppointmentsByUser(int userId) {
        return appointmentDAO.getAppointmentsByUser(userId);
    }

    public List<FAQ> getAllFAQs() {
        return faqDAO.getAllFAQs();
    }

    public void addFAQ(FAQ faq) {
        faqDAO.addFAQ(faq);
    }

    public void deleteFAQ(int id) {
        faqDAO.deleteFAQ(id);
    }
}
