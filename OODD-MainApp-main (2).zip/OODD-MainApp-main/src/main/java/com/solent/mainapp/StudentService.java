package com.solent.mainapp;

import com.solent.mainapp.dao.AppointmentDAO;
import java.sql.Connection;
import java.util.List;

public class StudentService {
    private AppointmentDAO appointmentDAO;

    public StudentService(Connection conn) {
        this.appointmentDAO = new AppointmentDAO(conn);
    }

    public void bookAppointment(Appointment appointment) {
        appointmentDAO.bookAppointment(appointment);
    }

    public List<Appointment> getAppointments(int userId) {
        return appointmentDAO.getAppointmentsByUser(userId);
    }
}
