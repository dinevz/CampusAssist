package com.solent.mainapp;

import com.solent.mainapp.dao.UserDAO;
import java.sql.Connection;

public class UserService {
    private UserDAO userDAO;

    public UserService(Connection conn) {
        this.userDAO = new UserDAO(conn);
    }

    public User login(String username, String password) {
        return userDAO.login(username, password);
    }
}
