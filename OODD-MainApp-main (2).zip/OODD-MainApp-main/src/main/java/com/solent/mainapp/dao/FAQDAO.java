package com.solent.mainapp.dao;

import com.solent.mainapp.FAQ;
import java.sql.*;
import java.util.*;

public class FAQDAO {
    private Connection conn;

    public FAQDAO(Connection conn) {
        this.conn = conn;
    }

    public List<FAQ> getAllFAQs() {
        List<FAQ> list = new ArrayList<>();
        String sql = "SELECT * FROM faqs";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                FAQ faq = new FAQ(
                    rs.getInt("id"),
                    rs.getString("question"),
                    rs.getString("answer"),
                    rs.getString("category")
                );
                list.add(faq);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public void addFAQ(FAQ faq) {
        String sql = "INSERT INTO faqs (question, answer, category) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, faq.getQuestion());
            stmt.setString(2, faq.getAnswer());
            stmt.setString(3, faq.getCategory());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteFAQ(int id) {
        String sql = "DELETE FROM faqs WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
