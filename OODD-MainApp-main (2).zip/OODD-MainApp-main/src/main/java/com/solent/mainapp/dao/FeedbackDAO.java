package com.solent.mainapp.dao;

import java.sql.*;
import com.solent.mainapp.Feedback;
import java.util.*;

public class FeedbackDAO {
    private Connection conn;

    public FeedbackDAO(Connection conn) {
        this.conn = conn;
    }

    public void submitFeedback(Feedback feedback) {
        String sql = "INSERT INTO feedback (appointment_id, rating, comments, category) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, feedback.getAppointmentId());
            stmt.setInt(2, feedback.getRating());
            stmt.setString(3, feedback.getComments());
            stmt.setString(4, feedback.getCategory());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    publi
