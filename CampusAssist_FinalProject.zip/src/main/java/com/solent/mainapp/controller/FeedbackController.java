package com.solent.mainapp.controller;

import com.solent.mainapp.Feedback;
import com.solent.mainapp.dao.FeedbackDAO;
import com.solent.mainapp.DataManager;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class FeedbackController extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int appointmentId = Integer.parseInt(request.getParameter("appointmentId"));
        int rating = Integer.parseInt(request.getParameter("rating"));
        String comments = request.getParameter("comments");
        String category = request.getParameter("category");

        Feedback feedback = new Feedback(0, appointmentId, rating, comments, category);
        FeedbackDAO dao = new FeedbackDAO(DataManager.getConnection());
        dao.submitFeedback(feedback);

        response.sendRedirect("studentDashboard.jsp");
    }
}
