package com.solent.mainapp.controller;

import com.solent.mainapp.FAQ;
import com.solent.mainapp.FAQService;
import com.solent.mainapp.DataManager;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class FAQController extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        FAQService service = new FAQService(DataManager.getConnection());
        List<FAQ> faqList = service.getAllFAQs();

        request.setAttribute("faqs", faqList);
        request.getRequestDispatcher("faqs.jsp").forward(request, response);
    }
}
