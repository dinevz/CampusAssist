package com.solent.mainapp.controller;

import com.solent.mainapp.Appointment;
import com.solent.mainapp.StudentService;
import com.solent.mainapp.DataManager;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class StudentController extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int userId = ((com.solent.mainapp.User) request.getSession().getAttribute("user")).getId();
        StudentService service = new StudentService(DataManager.getConnection());
        List<Appointment> appointments = service.getAppointments(userId);

        request.setAttribute("appointments", appointments);
        request.getRequestDispatcher("viewAppointments.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int userId = ((com.solent.mainapp.User) request.getSession().getAttribute("user")).getId();
        String category = request.getParameter("category");
        String date = request.getParameter("date");
        String time = request.getParameter("time");

        Appointment appointment = new Appointment(0, userId, category, date, time, "pending");
        StudentService service = new StudentService(DataManager.getConnection());
        service.bookAppointment(appointment);

        response.sendRedirect("studentDashboard.jsp");
    }
}
