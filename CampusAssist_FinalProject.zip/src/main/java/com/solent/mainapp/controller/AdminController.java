package com.solent.mainapp.controller;

import com.solent.mainapp.AdminService;
import com.solent.mainapp.Appointment;
import com.solent.mainapp.FAQ;
import com.solent.mainapp.DataManager;
import com.solent.mainapp.dao.FeedbackDAO;
import com.solent.mainapp.Feedback;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class AdminController extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        AdminService service = new AdminService(DataManager.getConnection());
        List<FAQ> faqs = service.getAllFAQs();
        request.setAttribute("faqs", faqs);

        FeedbackDAO feedbackDAO = new FeedbackDAO(DataManager.getConnection());
        List<Feedback> feedbackList = feedbackDAO.getAllFeedback();
        request.setAttribute("feedbackList", feedbackList);

        request.getRequestDispatcher("adminDashboard.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        AdminService service = new AdminService(DataManager.getConnection());

        if ("addFAQ".equals(action)) {
            String question = request.getParameter("question");
            String answer = request.getParameter("answer");
            String category = request.getParameter("category");
            FAQ faq = new FAQ(0, question, answer, category);
            service.addFAQ(faq);
        } else if ("deleteFAQ".equals(action)) {
            int id = Integer.parseInt(request.getParameter("faqId"));
            service.deleteFAQ(id);
        }

        response.sendRedirect("adminDashboard.jsp");
    }
}
