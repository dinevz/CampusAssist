﻿# OODD-MainApp - QHO543 Group Project
A console-based Java application for student support services.

## Group Members
- Zhivko: Student features (session requests, feedback, reminders)
- Catalin: Admin features (appointment management, user roles)
- George: FAQs and analytics

## Setup
1. Clone: `git clone https://github.com/username/OODD-MainApp.git`
2. Open in NetBeans IDE 21.
3. Run `MainApp.java`.
